Split/Second SDL Controller Fix 1.4

INSTALLATION
1. Close Split/Second.
2. Extract all three DLL files and this README.txt into the game folder beside SplitSecond.exe.
3. If prompted, replace files from an earlier version of this controller fix.
4. Start the game normally.

The ZIP contains dinput8.dll, sspad.dll, and SDL3.dll. No external controller mapper or Steam configuration is needed. Back up an existing dinput8.dll from another mod before replacing it; compatibility with other mods has not been verified.

This fix was tested with a particular Windows PC executable. Other editions may not support every feature. See the GitHub repository for source code, licenses, test results, and compatibility details:
https://github.com/philippkoerber98/splitsecond-sdl-controller-fix

The tests used virtual SDL gamepads. Physical Xbox One/8BitDo controllers and vibration motors were not available for testing. The original game executable is not included or modified by this package.

Before installing, close the game and make a backup of the original files in the game folder.

